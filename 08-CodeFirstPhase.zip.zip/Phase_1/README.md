# Project1.2-Group_08

V_1.0 @17/03/2022

*****Welcome to Crazy Putting: a Golf Game, developed by Group 8, aka "Amazes"*****

# MEMBERS: Mahshid Archangi, Emmanuel Fernandez, Jeroen Geraats, Sam Goldie, Juan Manuel López-Yanes Redivo, Selma Rimmelzwaan, Alexandra Zamfir

# HOW TO START THIS PROGRAM: 

    *o start the Crazy Putting game, run the file:
#                                                  DesktopLauncher.java 

    To chose the desired initial inputs, use the static String parameters filePathInput -for inputs- and filePathVelocity -for initial velocity- in FileInputManager and enter the desired file path to use.
    Alternatively, change the initial parameters in the file currently selected (by defaul input_1.txt and velocity.txt).

    To shoot the ball, drag the mouse from the golf ball: a line will appear to help in the aiming.

